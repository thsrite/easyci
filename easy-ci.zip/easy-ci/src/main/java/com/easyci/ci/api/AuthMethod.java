package com.easyci.ci.api;

public enum AuthMethod {
    HEADER, URL_PARAMETER
}
