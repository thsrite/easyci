package com.easyci.ci.api.models;

public class GitlabGroupMember extends GitlabAbstractMember {
}
