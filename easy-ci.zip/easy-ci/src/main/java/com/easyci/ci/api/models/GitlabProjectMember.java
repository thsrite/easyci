package com.easyci.ci.api.models;

public class GitlabProjectMember extends GitlabAbstractMember {
}
