if [ -f $1 ];then 
	echo "文件存在";
else 
	echo "文件不存在"; 
fi
